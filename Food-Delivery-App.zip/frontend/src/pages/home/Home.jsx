import Hero from "../hero/Hero";

const Home = () => {
  return (
    <div className="home">
      <div className="hero">
        <Hero />
      </div>
    </div>
  );
};

export default Home;
