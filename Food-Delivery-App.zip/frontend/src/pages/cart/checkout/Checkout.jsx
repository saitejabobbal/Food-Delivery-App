
const Checkout = () => {
    return (
        <div>
            <h3>Checkout page</h3>
        </div>
    )
}

export default Checkout
